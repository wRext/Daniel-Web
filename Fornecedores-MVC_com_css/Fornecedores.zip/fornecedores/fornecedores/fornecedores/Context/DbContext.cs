﻿using Microsoft.EntityFrameworkCore;
using fornecedores.Models;

namespace fornecedores.Context
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {
        }

        // DbSet para a tabela de fornecedores
        public DbSet<Fornecedor> Fornecedores { get; set; }
    }
}

