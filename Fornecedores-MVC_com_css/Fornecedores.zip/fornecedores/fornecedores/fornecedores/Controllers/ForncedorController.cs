﻿using fornecedores.Context;
using fornecedores.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace fornecedores.Controllers
{
    public class FornecedorController : Controller
    {
        private readonly AppDbContext _context;

        public FornecedorController(AppDbContext context)
        {
            _context = context;
        }
        // HOME: Página inicial
        public IActionResult HomePage()
        {
            return View("~/Views/CrudFornecedores/HomePage.cshtml");
        }
        // INDEX: Lista todos os fornecedores
        public async Task<IActionResult> Index()
        {
            var fornecedores = await _context.Fornecedores.ToListAsync();
            return View("~/Views/CrudFornecedores/Index.cshtml", fornecedores); // Caminho manual
        }

        // CREATE: Exibe o formulário de criação
        public IActionResult Create()
        {
            return View("~/Views/CrudFornecedores/Create.cshtml"); // Caminho manual
        }

        // CREATE: Salva um novo fornecedor no banco de dados
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Fornecedor fornecedor)
        {
            if (ModelState.IsValid)
            {
                _context.Add(fornecedor);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View("~/Views/CrudFornecedores/Create.cshtml", fornecedor); // Caminho manual
        }

        // DETAILS: Exibe detalhes de um fornecedor específico
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
                return NotFound();

            var fornecedor = await _context.Fornecedores
                .FirstOrDefaultAsync(f => f.Id == id);

            if (fornecedor == null)
                return NotFound();

            return View("~/Views/CrudFornecedores/Details.cshtml", fornecedor); // Caminho manual
        }

        // EDIT: Exibe o formulário de edição
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
                return NotFound();

            var fornecedor = await _context.Fornecedores.FindAsync(id);

            if (fornecedor == null)
                return NotFound();

            return View("~/Views/CrudFornecedores/Edit.cshtml", fornecedor); // Caminho manual
        }

        // EDIT: Salva as alterações no banco de dados
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, Fornecedor fornecedor)
        {
            if (id != fornecedor.Id)
                return NotFound();

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(fornecedor);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!FornecedorExists(fornecedor.Id))
                        return NotFound();
                    else
                        throw;
                }
                return RedirectToAction(nameof(Index));
            }
            return View("~/Views/CrudFornecedores/Edit.cshtml", fornecedor); // Caminho manual
        }

        // DELETE: Exibe a confirmação de exclusão
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
                return NotFound();

            var fornecedor = await _context.Fornecedores
                .FirstOrDefaultAsync(f => f.Id == id);

            if (fornecedor == null)
                return NotFound();

            return View("~/Views/CrudFornecedores/Delete.cshtml", fornecedor); // Caminho manual
        }

        // DELETE: Exclui o fornecedor do banco de dados
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var fornecedor = await _context.Fornecedores.FindAsync(id);

            if (fornecedor != null)
            {
                _context.Fornecedores.Remove(fornecedor);
                await _context.SaveChangesAsync();
            }

            return RedirectToAction(nameof(Index));
        }

        // Método auxiliar para verificar se um fornecedor existe
        private bool FornecedorExists(int id)
        {
            return _context.Fornecedores.Any(e => e.Id == id);
        }
    }
}
