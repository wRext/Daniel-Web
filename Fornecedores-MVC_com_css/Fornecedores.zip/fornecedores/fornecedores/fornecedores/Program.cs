using Microsoft.EntityFrameworkCore;
using fornecedores.Context;

var builder = WebApplication.CreateBuilder(args);

// Registra o DbContext para o aplicativo
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("FornecedorDb")));

// Adiciona os servi�os de MVC e Razor
builder.Services.AddControllersWithViews()
    .AddRazorOptions(options =>
    {
        options.ViewLocationFormats.Add("/Views/CrudFornecedores/{1}/{0}.cshtml"); // Especifica o caminho das views
    });

var app = builder.Build();

// Configura��o do pipeline de requisi��es HTTP
if (app.Environment.IsDevelopment())
{
    app.UseDeveloperExceptionPage();
}
else
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Fornecedor}/{action=HomePage}/{id?}");

app.Run();
